var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/products', function (req, res) {

    // Get the Mongo Client to work with MongoDB server
    var MongoClient = mongodb.MongoClient;

    // Define where the Mongo Server is 

    var url = "mongodb://localhost:27017/products";

    MongoClient.connect(url, function (err, db) {
        if (err) {
            console.log('Error : ' + err)
        }
        else {
            // We are connected
            console.log('Connected successfully to ' + url);

            var collection = db.collection("products")

            //Find all the products
            collection.find({}).toArray(function (err, result) {
                if (err) {
                    console.log('Error : ' + err)
                } else if (result.length) {
                    res.render('productlist', {
                        productlist: result
                    });
                }
                else {
                    res.send('No Products found !');
                }
                db.close();
            });
        }
    });
});

module.exports = router;
