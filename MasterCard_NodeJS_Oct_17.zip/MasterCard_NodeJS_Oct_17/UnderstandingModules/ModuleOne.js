

function Sum(x,y){
return x + y;
}

function Product(x,y){
    return x * y;
    }

// module.exports.Addition =  Sum;
// module.exports.Multiplication = Product;

module.exports = {
    Addition:Sum,
    Multiplication:Product
}