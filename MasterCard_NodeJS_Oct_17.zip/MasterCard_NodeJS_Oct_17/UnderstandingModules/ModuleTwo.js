var modOne = require('./ModuleOne');

console.log('The addition is : ' + modOne.Addition(10,20));