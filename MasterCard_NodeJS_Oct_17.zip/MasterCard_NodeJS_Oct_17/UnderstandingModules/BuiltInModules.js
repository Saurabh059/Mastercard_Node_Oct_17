var fs = require('fs'); // built-in module
fs.readFile('Data.txt',function(err,dataFromFile){
    if(err){
        console.log('Error ' + err)
    }else{
        console.log('Reading Result (Async) : ' + dataFromFile)
    }
});

console.log('End Of Program !');
