var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var router = express.Router();

app.get('/',function(req,res){ 
    //res.send('<h1>Welcome to express !</h1>');
    res.sendFile('Hello.html',{root:__dirname});
    //var person = {name:'Sumeet',location:'Pune'}
    //res.json(person);
});
app.use(bodyParser.urlencoded({extended:false}));// to read values from request body !

app.post('/login',function(req,res){
    // read the data from the text boxes !
    console.log('Welcome ' + req.body.username  );
    res.send('success');
})


// localhhost:3500/api/products
// router.route('/products').get(function(req,res){
//         var products = [
//             {Name:'Laptop',Price:20000},
//             {Name:'TV',Price:50000},
//             {Name:'Mobile',Price:30000}            
//         ];
//         res.json(products);
// });

// router.route('/products/:name').get(function(req,res){
//     var pName = req.params.name;
//     res.end('You searched for : ' + pName);
// });

router.route('/products/:from-:to').get(function(req,res){
      var products = [
                    {Name:'Laptop',Price:20000},
                    {Name:'TV',Price:50000},
                    {Name:'Mobile',Price:30000}            
                ];
                var fromRange = req.params.from;
                var toRange = req.params.to;
                res.json(products.slice(fromRange,toRange))

});

app.use('/api',router);

app.use(function(req,res){
    res.writeHead(404);
    res.end('Resource Not Found !');
})

app.listen(3500,function(){
    console.log('Server running at 3500 !');
})