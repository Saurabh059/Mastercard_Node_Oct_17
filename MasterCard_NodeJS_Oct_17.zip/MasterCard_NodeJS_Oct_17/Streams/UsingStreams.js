var fs = require('fs');

var readableStream = fs.createReadStream('Input.txt');

var writableStream = fs.createWriteStream('Output.txt');

readableStream.setEncoding('UTF8');

var allData = '';

// readableStream.on('data',function(chunk){
//     allData+=chunk;
// });

// readableStream.on('end',function(){
//     writableStream.write(allData);
//     writableStream.end();
// });


readableStream.pipe(writableStream);// read from readableStream & write to writable stream !