

function processResult(err,result){
    if(err){
        console.log('' + err)
    }
    else{
        console.log('The result is : ' + result)
    }
}

function Multiplier(theNumber,callBackFunc){
    if(theNumber % 2 == 0){
        setTimeout(function(){
            callBackFunc(null,theNumber * 10);
        },200);
    }
    else{
        setTimeout(function(){
            callBackFunc(new Error('U passed an odd input !'),null)
        },200);
    }
}

Multiplier(2,processResult);
Multiplier(26,processResult);
Multiplier(7,processResult);
