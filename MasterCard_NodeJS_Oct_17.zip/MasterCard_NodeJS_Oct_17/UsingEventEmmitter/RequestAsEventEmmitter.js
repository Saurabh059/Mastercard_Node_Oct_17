var request = require('request');// 3rd Party
var fs = require('fs'); // built -in

var req = request('http://www.google.com'); // returns an instance of Event Emitter Object

var response = '';

req.on('data',function(chunkOfData){
    console.log('\n\n >>>>>>>>>>>>>>>>>>>>>>>>>> Data >>>>>>>>>>>>>>>  \n\n' + chunkOfData)
    response+= chunkOfData;
});

req.on('end',function(){
    console.log('>>>>>DONE >>>>>>');
    fs.writeFile('MyGoogleResponse.html',response)
})