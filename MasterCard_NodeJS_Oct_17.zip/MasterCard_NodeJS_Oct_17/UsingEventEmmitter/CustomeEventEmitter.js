var EventEmitter = require('events').EventEmitter; // built in

function getResource(maxIteration){
    var e = new EventEmitter();
    // emit the events
    process.nextTick(function(){
            e.emit('start');

            var cnt = 0;
         var t=  setInterval(function(){
                e.emit('item',++cnt)

                
                if(cnt == 8){
                    e.emit('error',cnt);
                    clearInterval(t);
                }

                if(cnt == maxIteration){
                    e.emit('done',cnt);
                    clearInterval(t);
                }
            },1000);           
    }); // delay the emitting of events after some time !
    // return an event emitter !
    return e;
}

// Subscriber

var res = getResource(10);//return an event emitter

res.on('item',function(i){
    console.log('I Received : ' + i);
});

res.on('start',function(){
    console.log('Iteration started');
});

res.on('done',function(i){
    console.log('Ended with count : ' + i);
});

res.on('error',function(err){
    console.log('Ended with error with count : ' + err);
});