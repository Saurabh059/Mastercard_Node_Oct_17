var express = require('express');

var routes = express.Router();
routes.get('/',function(req,res){
    res.render('index',{  // index.jade
        title : 'Using Jade !',
        message:'Working with block code',
        products:[
            {name:'TV',price:30000},
            {name:'Mobile',price:20000},
            {name:'PS2',price:40000}            
        ]
    });
});

module.exports = routes;