var http = require('http'); // default (built-in)
var fs = require('fs');
var socket = require('socket.io');
var server = http.createServer(function(req,res){
    fs.readFile(__dirname+'/Client.html',(err,data)=>{  // arrow functions
        if(err){
            console.log(err)
        }else{
            res.writeHead(200,{'Content-Type':'text/html'});
            return res.end(data);
        }
    }); // eof readfile
});
server.listen(3300,'127.0.0.1');
var io = socket.listen(server);
io.sockets.on('connection',function(skt){
        setInterval(function(){
                var msgs = new Date();// custom Data
                // console.log('Emmitted : ' + msgs);
                skt.emit('message',msgs);// emit msgs for client
        },2000);

        skt.on('submit',function(dataFromClient){ // subscribe for events from client
            console.log(dataFromClient);
        });
});

console.log('Server running at 3300 !');

