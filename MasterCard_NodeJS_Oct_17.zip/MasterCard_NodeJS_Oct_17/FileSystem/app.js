var fs = require('fs');

if(fs.existsSync('temp')){
    console.log('Dir found.. deleting..');
    if(fs.existsSync('temp/test.txt')){
        fs.unlinkSync('temp/test.txt'); // removing the file !
    }
    fs.rmdirSync('temp');
}

fs.mkdirSync('temp');

if(fs.existsSync('temp')){
    process.chdir('temp');
    fs.writeFileSync('test.txt','This is some sample text to be written !');
    //fs.renameSync('test.txt','newtest.txt');
    console.log('File has a size of : ' + fs.statSync('test.txt').size + " bytes !");
    console.log('File Contents : ' + fs.readFileSync('test.txt').toString())
}
console.log('Program Ended !');