var fs = require('fs');

fs.mkdir('temp',function(err){
        if(err){
            console.log(err)
        }else{
            fs.exists('temp',function(exists){
                if(exists){
                    process.chdir('temp');
                    fs.writeFile('test.txt','This is some sample text to be written (Async) !',function(err){
                        if(err){
                            console.log(err)
                        }else{
                            fs.stat('test.txt',function(err,stats){
                                console.log('File has a size of : ' + stats.size + " bytes !");
                                fs.readFile('test.txt',function(err,data){
                                    console.log('File Contents : ' + data.toString());
                                });
                            });
                        }
                    });
                }
            });
        }
});


console.log('Program Ended !');
