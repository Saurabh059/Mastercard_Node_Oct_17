var http = require('http');
var fs = require('fs');

var hostName = "127.0.0.1";
var server = http.createServer((req,res)=>{
    // res.statusCode = 200;
    // res.setHeader('Content-Type','text/html');
    // res.end('<h1>Hello World !</h1>');

        fs.readFile(__dirname+'/Hello.html',(err,data)=>{  // arrow functions
            if(err){
                console.log(err)
            }else{
                res.writeHead(200,{'Content-Type':'text/html'});
                return res.end(data);
            }
        }); // eof readfile
});// eof create Server

server.listen(3000,hostName,function(){
    console.log(`Server is running at ${hostName} ` );// String Interpolation
});